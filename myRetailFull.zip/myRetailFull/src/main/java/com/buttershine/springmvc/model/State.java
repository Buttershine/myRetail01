package com.buttershine.springmvc.model;

public enum State {

	NEW,USED;
}
